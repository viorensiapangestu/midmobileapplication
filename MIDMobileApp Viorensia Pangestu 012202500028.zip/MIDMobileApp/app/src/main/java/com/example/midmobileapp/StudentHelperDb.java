package com.example.midmobileapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class StudentHelperDb extends SQLiteOpenHelper {


    private static final String DATABASE_NAME = "Database1.db";
    private static final int DATABASE_VERSION = 1;


    public static final String TABLE_STUDENTS = "students";
    public static final String COL_ID = "_id";
    public static final String COL_NAME = "student_name";
    public static final String COL_STUDENT_ID = "student_id";
    public static final String COL_ENROLLED = "is_enrolled";

    public StudentHelperDb(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_STUDENTS + " ("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_NAME + " TEXT NOT NULL, "
                + COL_STUDENT_ID + " TEXT NOT NULL UNIQUE, "
                + COL_ENROLLED + " INTEGER NOT NULL DEFAULT 0"
                + ")";

        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENTS);
        onCreate(db);
    }


    public long addStudent(String name, String studentId, boolean enrolled) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_NAME, name);
        values.put(COL_STUDENT_ID, studentId);
        values.put(COL_ENROLLED, enrolled ? 1 : 0);

        return db.insert(TABLE_STUDENTS, null, values);
    }


    public int updateStudent(String studentId, String name, boolean enrolled) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_NAME, name);
        values.put(COL_ENROLLED, enrolled ? 1 : 0);

        return db.update(
                TABLE_STUDENTS,
                values,
                COL_STUDENT_ID + " = ?",
                new String[]{studentId}
        );
    }


    public int deleteStudent(String studentId) {
        SQLiteDatabase db = this.getWritableDatabase();

        return db.delete(
                TABLE_STUDENTS,
                COL_STUDENT_ID + " = ?",
                new String[]{studentId}
        );
    }


    public Cursor getAllStudents() {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                TABLE_STUDENTS,
                null,
                null,
                null,
                null,
                null,
                COL_NAME + " ASC"
        );
    }


    public Cursor getStudentById(String studentId) {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                TABLE_STUDENTS,
                null,
                COL_STUDENT_ID + " = ?",
                new String[]{studentId},
                null,
                null,
                null
        );
    }
}
