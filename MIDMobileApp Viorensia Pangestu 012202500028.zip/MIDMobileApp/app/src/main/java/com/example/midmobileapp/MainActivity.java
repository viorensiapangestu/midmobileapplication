package com.example.midmobileapp;

import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText etStudentName;
    private EditText etStudentId;
    private CheckBox cbEnrolled;
    private TextView tvSelected;
    private TextView tvEmpty;
    private ListView lvStudents;

    private Button btnAdd;
    private Button btnEdit;
    private Button btnView;
    private Button btnDelete;


    private StudentHelperDb dbHelper;

    private ArrayList<String> studentList;
    private ArrayList<String> studentIds;
    private ArrayAdapter<String> adapter;

    private String selectedStudentId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize interface components
        etStudentName = findViewById(R.id.etStudentName);
        etStudentId = findViewById(R.id.etStudentId);
        cbEnrolled = findViewById(R.id.cbEnrolled);
        tvSelected = findViewById(R.id.tvSelected);
        tvEmpty = findViewById(R.id.tvEmpty);
        lvStudents = findViewById(R.id.lvStudents);

        btnAdd = findViewById(R.id.btnAdd);
        btnEdit = findViewById(R.id.btnEdit);
        btnView = findViewById(R.id.btnView);
        btnDelete = findViewById(R.id.btnDelete);

        // Initialize SQLite database
        dbHelper = new StudentHelperDb(this);

        studentList = new ArrayList<>();
        studentIds = new ArrayList<>();

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                studentList
        );

        lvStudents.setAdapter(adapter);

        // ADD button
        btnAdd.setOnClickListener(v -> addStudent());

        // EDIT button
        btnEdit.setOnClickListener(v -> editStudent());

        // VIEW button
        btnView.setOnClickListener(v -> loadStudents());

        // DELETE button
        btnDelete.setOnClickListener(v -> deleteStudent());

        // Select a student from the list
        lvStudents.setOnItemClickListener(
                (parent, view, position, id) -> {
                    selectedStudentId = studentIds.get(position);
                    showStudentDetails(selectedStudentId);
                }
        );


        loadStudents();
    }


    private void addStudent() {
        String name = etStudentName.getText().toString().trim();
        String studentId = etStudentId.getText().toString().trim();
        boolean enrolled = cbEnrolled.isChecked();

        if (name.isEmpty() || studentId.isEmpty()) {
            showMessage("Please enter both Student Name and Student ID.");
            return;
        }

        try {
            long result = dbHelper.addStudent(
                    name,
                    studentId,
                    enrolled
            );

            if (result != -1) {
                showMessage("Student added successfully.");
                clearForm();
                loadStudents();
            } else {
                showMessage("Failed to add student.");
            }

        } catch (SQLiteConstraintException e) {
            showMessage("This Student ID already exists.");
        }
    }


    private void editStudent() {
        String name = etStudentName.getText().toString().trim();
        String studentId = etStudentId.getText().toString().trim();
        boolean enrolled = cbEnrolled.isChecked();

        if (selectedStudentId == null) {
            showMessage("Please select a student from the list first.");
            return;
        }

        if (name.isEmpty() || studentId.isEmpty()) {
            showMessage("Please enter both Student Name and Student ID.");
            return;
        }

        if (!studentId.equals(selectedStudentId)) {
            showMessage("Student ID cannot be changed during editing.");
            return;
        }

        int result = dbHelper.updateStudent(
                selectedStudentId,
                name,
                enrolled
        );

        if (result > 0) {
            showMessage("Student updated successfully.");
            clearForm();
            loadStudents();
        } else {
            showMessage("No changes were made or the student was not found.");
        }
    }


    private void deleteStudent() {
        String studentId = selectedStudentId;

        if (studentId == null) {
            studentId = etStudentId.getText().toString().trim();
        }

        if (studentId.isEmpty()) {
            showMessage("Please select a student or enter a Student ID.");
            return;
        }

        int result = dbHelper.deleteStudent(studentId);

        if (result > 0) {
            showMessage("Student deleted successfully.");
            clearForm();
            loadStudents();
        } else {
            showMessage("Student not found.");
        }
    }


    private void loadStudents() {
        studentList.clear();
        studentIds.clear();

        Cursor cursor = dbHelper.getAllStudents();

        try {
            while (cursor.moveToNext()) {

                String id = cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                StudentHelperDb.COL_STUDENT_ID
                        )
                );

                String name = cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                StudentHelperDb.COL_NAME
                        )
                );

                int enrolledValue = cursor.getInt(
                        cursor.getColumnIndexOrThrow(
                                StudentHelperDb.COL_ENROLLED
                        )
                );

                String enrolledText =
                        enrolledValue == 1 ? "Yes" : "No";

                studentIds.add(id);

                studentList.add(
                        "Name: " + name
                                + "\nStudent ID: " + id
                                + "\nHas Enrolled: " + enrolledText
                );
            }
        } finally {
            cursor.close();
        }

        adapter.notifyDataSetChanged();

        if (studentList.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            tvEmpty.setText("No student records found.");
        } else {
            tvEmpty.setVisibility(View.GONE);
        }
    }


    private void showStudentDetails(String studentId) {
        Cursor cursor = dbHelper.getStudentById(studentId);

        try {
            if (cursor.moveToFirst()) {

                String name = cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                StudentHelperDb.COL_NAME
                        )
                );

                String id = cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                StudentHelperDb.COL_STUDENT_ID
                        )
                );

                int enrolled = cursor.getInt(
                        cursor.getColumnIndexOrThrow(
                                StudentHelperDb.COL_ENROLLED
                        )
                );

                etStudentName.setText(name);
                etStudentId.setText(id);
                cbEnrolled.setChecked(enrolled == 1);

                tvSelected.setText("Selected Student ID: " + id);

            } else {
                showMessage("Student not found.");
            }
        } finally {
            cursor.close();
        }
    }


    private void clearForm() {
        etStudentName.setText("");
        etStudentId.setText("");
        cbEnrolled.setChecked(false);

        selectedStudentId = null;
        tvSelected.setText("No student selected.");

        etStudentName.requestFocus();
    }


    private void showMessage(String message) {
        Toast.makeText(
                this,
                message,
                Toast.LENGTH_SHORT
        ).show();
    }

    @Override
    protected void onDestroy() {
        if (dbHelper != null) {
            dbHelper.close();
        }

        super.onDestroy();
    }
}
